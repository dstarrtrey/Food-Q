import React from 'react';
import { Col, Row, Container } from "../components/Grid/index";
import Banner from "../components/Banner/index";
import { Input, TextArea, FormBtn } from "../components/Form";
import "./Home.css";
import { Link } from "react-router-dom";

// function Home() {
//   return (
//     <>
//     <div class="jumbotron jumbotron-fluid">
//     <h1 class="display-4">Fluid jumbotron</h1>
//     <p class="lead">Angry Fish Sushi</p> 
//     </div>
//     <div class="container-fluid">
//     <img src="images/sushi_img.jpg" alt="strawberry roll" height="600px" width="600px"></img>
//     <p className="owner-login">Welcome to Angry Fish Sushi</p>
    // <Link to="/Menu"><button className="search-button" type="submit">Browse Menu</button>
    // </Link>
//     <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
//     </div>
//     </div>
//     </>
//   );
// };
// export default Home;

function Home() {
  return (
    <div>
      <Banner backgroundImage="images/sushibanner.jpg">
        <h1>Angry Fish Sushi</h1>
        <h2>San Leandro, CA</h2>
      </Banner>
      <Container style={{ marginTop: 30 }}>
        <Row>
          <Col size="md-12 lrg-12">
            <h1 class="introheader">Header Here</h1>
          </Col>
        </Row>
        <Row>
          <Col size="md-12 lrg-12">
          <hr></hr>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc aliquet diam tortor, id
              consequat mauris ullamcorper eu. Orci varius natoque penatibus et magnis dis
              parturient montes, nascetur ridiculus mus. Pellentesque et dui id justo finibus
              sollicitudin at et metus. Ut feugiat tellus nec metus commodo, sed suscipit nisi
              gravida. Duis eget vestibulum quam, ut porttitor sem. Donec sagittis mi sollicitudin
              turpis semper, et interdum risus lobortis. Vestibulum suscipit nunc non egestas
              tristique. Proin hendrerit efficitur malesuada. Mauris lorem urna, sodales accumsan
              quam non, tristique tempor erat. Nullam non sem facilisis, tempus tortor sit amet,
              volutpat nisl. Ut et turpis non nunc maximus mollis a vitae tortor. Pellentesque
              mattis risus ac quam laoreet cursus. Praesent suscipit orci neque, vestibulum
              tincidunt augue tincidunt non. Duis consequat mattis tortor vitae mattis.
            </p>
            <p>
              Phasellus at rutrum nisl. Praesent sed massa ut ipsum bibendum porttitor. Sed
              malesuada molestie velit ac viverra. Quisque a ullamcorper purus. Curabitur luctus mi
              ac mi hendrerit semper. Nulla tincidunt accumsan lobortis. Mauris convallis sapien non
              nibh porta accumsan. Nunc volutpat tempus porttitor. Nunc congue dictum egestas.
              Aliquam blandit mi eu urna scelerisque, vitae volutpat ligula ultricies. Maecenas vel
              porta augue. Fusce mauris ex, dignissim et lacinia ut, tempus eget nibh.
            </p>
          </Col>
          <Link to="/Menu"><button className="search-button" type="submit">Browse Menu</button>
          </Link>
        </Row>
      </Container>
    </div>
  );
};
export default Home;


