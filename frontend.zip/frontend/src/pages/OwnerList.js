import React from "react";

function OwnerList() {
  return <h1>OwnerList</h1>;
}

export default OwnerList;
